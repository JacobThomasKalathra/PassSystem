This directory holds module specific configuration files.

The default httpd.conf file includes any files in this directory ending in
".conf".
