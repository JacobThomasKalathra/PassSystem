
<?php
{
$pass="bdidkouyoNKJHIg779VJFMNnbkljl";
function Encrypt($password, $data)
{

   $salt = substr(md5(mt_rand(), true), 8);

    $key = md5($password . $salt, true);
   $iv  = md5($key . $password . $salt, true);

   $ct = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $key, $data, MCRYPT_MODE_CBC, $iv);

    return base64_encode('Salted__' . $salt . $ct);
}

}




?>

