<?php
echo "$_POST[]";

?>