<?php
error_reporting(0);
   $dbhost = 'slc04wva.us.oracle.com';
   $dbpass = 'ru55';
   $db = '(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=slc04wva.us.oracle.com)(PORT=1521))(CONNECT_DATA=(SID=aepmsgld)))' ;
   $conn = oci_connect('EMDBO', $dbpass, $db);
?>