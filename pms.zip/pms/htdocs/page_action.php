<?php 

$out="hello";
	echo "$out";		
 function password () {
		return $out;
	};	


?>