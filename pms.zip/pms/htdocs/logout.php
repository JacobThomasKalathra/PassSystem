<?php
include ("session.php");
include("config.php");
  // session_start();
   session_destroy();
   header("Location: http://aepms.us.oracle.com");
   //if(session_destroy()) {
     // header("Location: index.html");
   //}
?>