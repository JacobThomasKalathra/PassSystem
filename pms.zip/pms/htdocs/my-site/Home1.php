<?php
include ("session.php");
echo "welcome $login_session";
?> 