<?php



?>

<!doctype html public "-//w3c//dtd html 3.2//en">

<html>

<head>
<title>Demo Multiple drop down list box </title>
</head>

<body>
<?Php
$cat=$_POST['cat'];
$subcat=$_POST['subcat'];

echo "Value of \$cat = $cat <br>Value of \$subcat = $subcat ";


?>
<br><br>
<a href=dd.php>Reset and start again</a>

<br><br>



</center> 
</body>

</html>
