The cgi-bin directory is configured by default in httpd.conf, and CGI
scripts placed here are active and accessible via the URI prefix /cgi-bin
