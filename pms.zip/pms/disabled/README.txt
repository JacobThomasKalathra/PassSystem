This directory holds module specific configuration files.

The default httpd.conf file excludes any files in this directory ending in
".conf".
